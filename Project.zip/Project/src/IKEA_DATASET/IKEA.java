package IKEA_DATASET;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

public class IKEA {
    private String name;
    private String category;
    private float price;
    private float oldPrice;
    private boolean sellableOnline;
    private String link;
    private String otherColors;
    private String shortDescription;
    private String designer;
    private float depth;
    private float height;

    public IKEA(String name, String category, float price, float oldPrice, boolean sellableOnline, String link, String otherColors, String shortDescription, String designer, float depth, float height) {
        this.name = name;
        this.category = category;
        this.price = price;
        this.oldPrice = oldPrice;
        this.sellableOnline = sellableOnline;
        this.link = link;
        this.otherColors = otherColors;
        this.shortDescription = shortDescription;
        this.designer = designer;
        this.depth = depth;
        this.height = height;
    }

    public static void toCSV(IKEA[] products, String fileName) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
            for (IKEA product : products) {
                writer.write(product.getName() + "," + product.getCategory() + "," + product.getPrice() + "," + product.getOldPrice()
                        + "," + product.isSellableOnline() + "," + product.getLink() + "," + product.getOtherColors() + ","
                        + product.getShortDescription() + "," + product.getDesigner() + "," + product.getDepth() + ","
                        + product.getHeight());
                writer.newLine();
            }
        }
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    public float getOldPrice() {
        return oldPrice;
    }

    public void setOldPrice(float oldPrice) {
        this.oldPrice = oldPrice;
    }

    public boolean isSellableOnline() {
        return sellableOnline;
    }

    public void setSellableOnline(boolean sellableOnline) {
        this.sellableOnline = sellableOnline;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getOtherColors() {
        return otherColors;
    }

    public void setOtherColors(String otherColors) {
        this.otherColors = otherColors;
    }

    public String getShortDescription() {
        return shortDescription;
    }

    public void setShortDescription(String shortDescription) {
        this.shortDescription = shortDescription;
    }

    public String getDesigner() {
        return designer;
    }

    public void setDesigner(String designer) {
        this.designer = designer;
    }

    public float getDepth() {
        return depth;
    }

    public void setDepth(float depth) {
        this.depth = depth;
    }

    public float getHeight() {
        return height;
    }

    public void setHeight(float height) {
        this.height = height;
    }
    public static void listRandom(IKEA[] products, int numToList) {
        // Generate a random list of numToList products from the given array
        Random rand = new Random();
        for (int i = 0; i < numToList; i++) {
            int index = rand.nextInt(products.length);
            System.out.println(products[index].toString());
        }
        System.out.println("Total number of entities listed: " + numToList);
    }
    public static void listTop(IKEA[] products, int numToList) {
        // Sort the array of products by price in ascending order
        // and then print the first numToList products
        for (int i = 0; i < numToList; i++) {
            System.out.println(products[i].toString());
        }
        System.out.println("Total number of entities listed: " + numToList);
    }
    public static void listBottom(IKEA[] products, int numToList) {
        // Sort the array of products by price in descending order
        // and then print the first numToList products
        Arrays.sort(products, new Comparator<IKEA>() {
            @Override
            public int compare(IKEA o1, IKEA o2) {
                return Float.compare(o2.getPrice(), o1.getPrice());
            }
        });
        for (int i = 0; i < numToList; i++) {
            System.out.println(products[i].toString());
        }
        System.out.println("Total number of entities listed: " + numToList);
    }
    public static void sort(IKEA[] products, final String field, final String order) {
        Arrays.sort(products, new Comparator<IKEA>() {
            @Override
            public int compare(IKEA o1, IKEA o2) {
                if (field.equals("name")) {
                    if (order.equals("ASC")) {
                        return o1.getName().compareTo(o2.getName());
                    } else {
                        return o2.getName().compareTo(o1.getName());
                    }
                } else if (field.equals("price")) {
                    if (order.equals("ASC")) {
                        return Float.compare(o1.getPrice(), o2.getPrice());
                    } else {
                        return Float.compare(o2.getPrice(), o1.getPrice());
                    }
                } else if (field.equals("designer")) {
                    if (order.equals("ASC")) {
                        return o1.getDesigner().compareTo(o2.getDesigner());
                    } else {
                        return o2.getDesigner().compareTo(o1.getDesigner());
                    }
                } else if (field.equals("category")) {
                    if (order.equals("ASC")) {
                        return o1.getCategory().compareTo(o2.getCategory());
                    } else {
                        return o2.getCategory().compareTo(o1.getCategory());
                    }
                } else if (field.equals("old_price")) {
                    if (order.equals("ASC")) {
                        return Float.compare(o1.getOldPrice(), o2.getOldPrice());
                    } else {
                        return Float.compare(o2.getOldPrice(), o1.getOldPrice());
                    }
                } else {
                    return 0;
                }
            }
        });
    }
    public static IKEA[] filter(IKEA[] products, String field, String rule, String value) {
        List<IKEA> results = new ArrayList<>();
        for (IKEA product : products) {
            boolean matches = true;
            if (field.equals("price")) {
                if (rule.equals("eq")) {
                    if (product.getPrice() != Float.parseFloat(value)) {
                        matches = false;
                    }
                } else if (rule.equals("gt")) {
                    if (product.getPrice() <= Float.parseFloat(value)) {
                        matches = false;
                    }
                } else if (rule.equals("lt")) {
                    if (product.getPrice() >= Float.parseFloat(value)) {
                        matches = false;
                    }
                } else if (rule.equals("ge")) {
                    if (product.getPrice() < Float.parseFloat(value)) {
                        matches = false;
                    }
                } else if (rule.equals("le")) {
                    if (product.getPrice() > Float.parseFloat(value)) {
                        matches = false;
                    }
                } else if (rule.equals("bt")) {
                    String[] values = value.split(",");
                    float min = Float.parseFloat(values[0]);
                    float max = Float.parseFloat(values[1]);
                    if (product.getPrice() < min || product.getPrice() > max) {
                        matches = false;
                    }
                } else if (rule.equals("null")) {
                    if (product.getPrice() != Float.parseFloat(null)) {
                        matches = false;
                    }
                }
            } else if (field.equals("designer")) {
                if (rule.equals("contains")) {
                    if (!product.getDesigner().contains(value)) {
                        matches = false;
                    }
                } else if (rule.equals("null")) {
                    if (product.getDesigner() != null) {
                        matches = false;
                    }
                }
            } else if (field.equals("sellable_online")) {
                if (rule.equals("eq")) {
                    if (product.isSellableOnline() != Boolean.parseBoolean(value)) {
                        matches = false;
                    }
                } else if (rule.equals("null")) {
                    if (product.isSellableOnline() != Boolean.parseBoolean(null)) {
                        matches = false;
                    }
                }
            }
            if (matches) {
                results.add(product);
            }
        }
        return results.toArray(new IKEA[results.size()]);
    }

        public static IKEA[] search(IKEA[] products, String field, String value) {
        List<IKEA> results = new ArrayList<>();
        for (IKEA product : products) {
            if (field.equals("name")) {
                if (product.getName().contains(value)) {
                    results.add(product);
                }
            } else if (field.equals("price")) {
                if (product.getPrice() == Float.parseFloat(value)) {
                    results.add(product);
                }
            } else if (field.equals("category")) {
                if (product.getCategory().contains(value)) {
                    results.add(product);
                }
            } else if (field.equals("old_price")) {
                if (product.getOldPrice() == Float.parseFloat(value)) {
                    results.add(product);
                }
            } else if (field.equals("designer")) {
                if (product.getDesigner().contains(value)) {
                    results.add(product);
                }
            }
        }
        return results.toArray(new IKEA[0]);
    }

    @Override
    public String toString() {
        return "IKEA{" +
                "name='" + name + '\'' +
                ", category='" + category + '\'' +
                ", price=" + price +
                ", oldPrice=" + oldPrice +
                ", sellableOnline=" + sellableOnline +
                ", link='" + link + '\'' +
                ", otherColors='" + otherColors + '\'' +
                ", shortDescription='" + shortDescription + '\'' +
                ", designer='" + designer + '\'' +
                ", depth=" + depth +
                ", height=" + height +
                '}';
    }

    public void displayAllFields() {
        System.out.println("Name: " + this.name);
        System.out.println("Category: " + this.category);
        System.out.println("Price: $" + this.price);
        System.out.println("Old Price: $" + this.oldPrice);
        System.out.println("Sellable Online: " + this.sellableOnline);
        System.out.println("Link: " + this.link);
        System.out.println("Other Colors: " + this.otherColors);
        System.out.println("Short Description: " + this.shortDescription);
        System.out.println("Designer: " + this.designer);
        System.out.println("Depth: " + this.depth);
        System.out.println("Height: " + this.height);
    }
    public void displaySelectedFields(String[] fieldsToDisplay) {
        for (String field : fieldsToDisplay) {
            switch (field) {
                case "name":
                    System.out.println("Name: " + this.name);
                    break;
                case "category":
                    System.out.println("Category: " + this.category);
                    break;
                case "price":
                    System.out.println("Price: $" + this.price);
                    break;
                case "old_price":
                    System.out.println("Old Price: $" + this.oldPrice);
                    break;
                case "sellable_online":
                    System.out.println("Sellable Online: " + this.sellableOnline);
                    break;
                case "link":
                    System.out.println("Link: " + this.link);
                    break;
                case "other_colors":
                    System.out.println("Other Colors: " + this.otherColors);
                    break;
                case "short_description":
                    System.out.println("Short Description: " + this.shortDescription);
                    break;
                case "designer":
                    System.out.println("Designer: " + this.designer);
                    break;
                case "depth":
                    System.out.println("Depth: " + this.depth);
                    break;
                case "height":
                    System.out.println("Height: " + this.height);
                    break;
                default:
                    break;
            }
        }
    }
}
