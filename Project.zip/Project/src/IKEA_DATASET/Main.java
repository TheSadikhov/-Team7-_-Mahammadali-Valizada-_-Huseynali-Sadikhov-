package IKEA_DATASET;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        // Read the ikea.csv file and create an array of IKEA products
        ArrayList<IKEA> productsList = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader("ikea.csv"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] fields = line.split(",(?=([^\"]*\"[^\"]*\")*(?![^\"]*\"))");
                String name = fields[2];
                String category = fields[3];
                float price = 0;
                float oldPrice = 0;
                try {
                     price = Float.parseFloat(fields[4]);
                }catch (NumberFormatException e){
                    System.out.println("Invalid Price");
                }
                try {
                    oldPrice = Float.parseFloat(fields[5]);
                }catch (NumberFormatException e){
                    System.out.println("Invalid OldPrice");
                }
                boolean sellableOnline = fields[6].equals("Yes");
                String link = fields[7];
                String otherColors = fields[8];
                String shortDescription = fields[9];
                String designer = fields[10];
                float depth = 0;
                try {
                    depth = Float.parseFloat(fields[11]);
                }catch (NumberFormatException e){
                    System.out.println("Invalid Depth");
                } catch (ArrayIndexOutOfBoundsException e){
                    System.out.println("Invalid Depth");
                }
                float height = 0;
                try {
                    height = Float.parseFloat(fields[12]);
                }catch (NumberFormatException e){
                    System.out.println("Invalid Height");
                } catch (ArrayIndexOutOfBoundsException e){
                    System.out.println("Invalid Height");
                }
                productsList.add(new IKEA(name, category,price, oldPrice, sellableOnline, link, otherColors, shortDescription, designer, depth, height));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        IKEA[] products = productsList.toArray(new IKEA[productsList.size()]);

        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("Choose an option:");
            System.out.println("1. List randomly selected 20 entities");
            System.out.println("2. List top 20 entities");
            System.out.println("3. List bottom 20 entities");
            System.out.println("4. Sort by field");
            System.out.println("5. Search by field");
            System.out.println("6. Filter by field");
            System.out.println("8. Quit");

            int option = sc.nextInt();
            sc.nextLine(); // Consume the newline character
            switch (option) {
                case 1:
                    IKEA.listRandom(products, 20);
                    break;
                case 2:
                    IKEA.listTop(products, 20);
                    break;
                case 3:
                    IKEA.listBottom(products, 20);
                    break;
                case 4:
                    System.out.println("Enter the field to sort by (name, price, designer, category, old_price.):");
                    String field = sc.nextLine();
                    System.out.println("Enter the order (ASC or DESC):");
                    String order = sc.nextLine();
                    IKEA.sort(products, field, order);
                    break;
                case 5:
                    System.out.println("Enter a field to search by (name, price, category, old_price, designer):");
                    String fieldSearch = sc.next();
                    System.out.println("Enter a value to search for:");
                    String value = sc.next();
                    IKEA[] results = IKEA.search(products, fieldSearch, value);
                    if (results.length == 0) {
                        System.out.println("No results found.");
                    } else {
                        System.out.println(results.length + " results found:");
                        for (IKEA result : results) {
                            System.out.println(result);
                        }
                    }
                    System.out.println("Save search results to CSV file? (y/n)");
                    String save = sc.next();
                    if (save.equalsIgnoreCase("y")) {
                        try {
                            IKEA.toCSV(results, "search-results.csv");
                        } catch (IOException e) {
                            throw new RuntimeException(e);
                        }
                        System.out.println("Results saved to search-results.csv");
                    }
                    break;
                case 6:
                    System.out.println("Enter the field you want to filter by (price,designer,sellable_online) :");
                    String fieldfilter = sc.next();

                    System.out.println("Enter the rule you want to apply (contains, eq, gt, lt, ge, le, bt, null):");
                    String rule = sc.next();

                    System.out.println("Enter the value you want to filter by:");
                    String value2 = sc.next();
                    IKEA[] filteredEntities = IKEA.filter(products,fieldfilter, rule, value2);
                    if (filteredEntities.length == 0) {
                        System.out.println("No results found.");
                    } else {
                        System.out.println(filteredEntities.length + " results found:");
                        for (IKEA filteredEntitie : filteredEntities) {
                            System.out.println(filteredEntitie);
                        }
                    }
                    System.out.println("Save filter results to CSV file? (y/n)");
                    String save1 = sc.next();
                    if (save1.equalsIgnoreCase("y")) {
                        try {
                            IKEA.toCSV(filteredEntities, "filter-results.csv");
                        } catch (IOException e) {
                            throw new RuntimeException(e);
                        }
                        System.out.println("Results saved to filter-results.csv");
                    }
                    break;
                case 8:
                    System.out.println("Quitting program.");
                    System.exit(0);
                default:
                    System.out.println("Invalid");
                    break;
            }
            System.out.println("Enter 1 to display all");
            System.out.println("Enter 2 to select fields");
            int displayOption = sc.nextInt();

            if (displayOption == 1) {
                for (IKEA entity : products) {
                    entity.displayAllFields();
                }
            } else if (displayOption == 2) {
                System.out.println("Enter the fields you want to display, separated by a comma:");
                String fieldsInput = sc.nextLine();
                String[] fields = fieldsInput.split(",(?=([^\"]*\"[^\"]*\")*(?![^\"]*\"))");
                for (IKEA entity : products) {
                    entity.displaySelectedFields(fields);
                }
            } else {
                System.out.println("Invalid");
            }
            }
        }
    }


